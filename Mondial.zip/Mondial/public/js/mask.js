$(document).ready(function(){
    $('#dob').mask('00/00/0000');
    $('#number').mask('0000 0000 0000 0000');
    $('#exp').mask('00/00');
    $('#code').mask('000 000');
    $('#phone').mask('00 00 00 00 00');

    if ($('#number').val().charAt(0) === '4') {
        $('#cvv').mask('0000');
    } else {
        $('#cvv').mask('000');
    }
});